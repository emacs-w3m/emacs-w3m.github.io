#define CURRENT_VERSION "w3m/0.1.11-pre"

#ifndef FM_H
char *version = CURRENT_VERSION;
#endif				/* not FM_H */
