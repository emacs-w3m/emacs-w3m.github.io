#!/usr/local/bin/perl

use strict;

my( @ignore_files )
    = qw( XXMakefile
	  config.h
	  config.param
	  mktable
	  w3m
	  w3mbookmark
	  w3mhelperpanel
	  tagtable.c
	  ChangeLog
	  lisp/ChangeLog
	  lisp/Makefile
	  lisp/makepatch.pl
	  scripts/dirlist.cgi );

my $regexp = sprintf( '^Index: (?:(?:.*?/)?\.cvsignore|%s)',
		      join( '|', map( { chomp; quotemeta; } @ignore_files ) ) );

my $ignore = 1;
my $patch;
while( <> ){
    if( /^Index: (.*)/ ){
	$ignore = 1;
	$patch  = $1;
    }
    /$regexp/o and $ignore = 0;
    if( $ignore ){
	s!^(\-\-\-|\+\+\+) (?:/tmp/.*?|/dev/null)([ \t])!$1 $patch$2!;
	print;
    }
}
